<?php $__env->startSection('title','Transition'); ?>
<?php $__env->startSection('style'); ?>
<style>

    .qr_box p{
       margin-bottom: -10px;
        z-index: 3;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="card-body card mt-2 d-flex flex-column justify-content-center align-items-center  qr_box">
    <p class="font-weight-bolder ">QR scan to pay <?php echo e($Auth_user->name); ?></p>
    <img class="w-50 h-50 "  src="data:image/png;base64, <?php echo base64_encode(QrCode::format('png')->size(300)->generate($Auth_user->phone)); ?> ">
    <span class="font-weight-bolder "> <?php echo e($Auth_user->phone); ?> </span>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('Frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivan/Desktop/web/laravel7/MagicPayNew/resources/views/Frontend/layouts/receiveQR.blade.php ENDPATH**/ ?>