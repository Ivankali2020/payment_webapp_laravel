<?php $__env->startSection('title','Confirm'); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .swal2-confirm,.swal2-cancel{
            border-radius: 8px !important;
        }
        .transfer img{
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: 1px solid deepskyblue;
            padding: 8px;
        }
        table td:first-child{
            animation: fadeInLeft calc(0.8s * 5) ;
        }
        table td:last-child{
           text-align: right ;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="card card-body mt-2 " >


        <div class="mt-3 transfer text-center ">
            <img src="https://image.flaticon.com/icons/png/128/1055/1055183.png" alt="">
            <h6 class="mt-2 font-weight-bold "> Confirm Transfer Box </h6>
        </div>
        <input type="hidden" value="<?php echo e($hashValue); ?>" name="hashValue">
        <div class="text-center">
            <table class="table table-borderless text-left mt-3  ">
                <tbody>
                <tr>
                    <td>TO</td>
                    <td><?php echo e($to_phone); ?></td>
                </tr>
                <tr>
                    <td>Name</td>
                    <td><?php echo e($to_user_name); ?></td>
                </tr>
                </tr>
                <tr>
                    <td>Amount</td>
                    <td><?php echo e($amount); ?> MMK</td>
                </tr>
                <tr>
                    <td>Description</td>
                    <td><?php echo e($description ? $description : '-'); ?></td>
                </tr>

                </tbody>
            </table>
        </div>

        <div class="text-center ">
            <button class="btn btn-primary " onclick="askTransfer()">Transfer</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        function askTransfer(){
            Swal.fire({
                title: 'Type Your Password!',
                html : '<input type="password" name="password" autofocus  class="form-control p text-center"/>',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Confirm',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    let password = $('.p').val();
                    // console.log(password);
                    $.ajax({
                        url : '/checkPassword/?password='+password,
                        method : 'GET',
                        data : {
                            amount : <?php echo e($amount); ?>,
                            to_phone : '<?php echo e($to_phone); ?>',
                            description : '<?php echo e($description ? $description : '-'); ?>',
                            hashValue : '<?php echo e($hashValue); ?>'
                        },
                        success : function (data){
                            console.log(data);
                            if(data.status == 'success'){
                                Swal.fire(
                                    {
                                        icon : 'success',
                                        html : `<div class="">

                                                <div class="card card-body my-2 " >
                                                    <small class="mb-1 " >Payment Bouncher</small>
                                                    <samll class="mb-3  "><?php echo e(date('d/m/Y H:m a')); ?></samll>

                                                    <div class="text-center font-weight-bolder ">
                                                            <p class="mb-1 " >Transfer</p>
                                                            <p class="text-danger">- <?php echo e($amount); ?>  Ks</p>
                                                    </div>

                                                </div>
                                        </div>`,
                                    }
                                )
                                setTimeout(()=>{
                                    location.href = 'transitionDetail/'+data.trx_id;
                                },2000)
                            }else {
                                Swal.fire(
                                    data.message,
                                    '',
                                    'error'
                                )
                            }
                        }
                    })

                }
            })
        }
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivan/Desktop/web/laravel7/MagicPayNew/resources/views/Frontend/transferConfirm.blade.php ENDPATH**/ ?>