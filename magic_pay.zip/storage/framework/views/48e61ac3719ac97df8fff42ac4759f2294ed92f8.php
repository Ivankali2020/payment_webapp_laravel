<?php $__env->startSection('title','Change Password'); ?>

<?php $__env->startSection('content'); ?>

    <div class="card card-body shadow ">
        <div class="mb-3 text-center wow fadeInDownBig ">
            <img src="<?php echo e(asset('img/security.png')); ?>" class="img-thumbnail w-25 shadow " alt="">
        </div>
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <small class="text-danger alert-danger alert "><?php echo e($error); ?></small>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <form action="<?php echo e(route('newPassword')); ?>" class="wow fadeIn" method="post" id="update">
            <?php echo csrf_field(); ?>

            <div class="form-group mb-3  ">
                <label for="">Old Password</label>
                <input type="text" class="form-control" name="oldPassword" >
            </div>

            <div class="form-group mb-3">
                <label for="">New Password</label>
                <input type="text" class="form-control" name="newPassword" >
            </div>

            <div class="form-group mb-3">
                <label for="">Confirm Password</label>
                <input type="text" class="form-control" value="<?php echo e(old('confirmPassword')); ?>" name="confirmPassword" >
            </div>

            <div class="form-group  wow fadeInUp ">
                <button type="submit" class="btn btn-block  btn-primary">Change New Password</button>
            </div>
        </form>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\NewAccountRequest', '#update');; ?>

    <script>

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivan/Desktop/web/laravel7/MagicPayNew/resources/views/Frontend/updatePassword.blade.php ENDPATH**/ ?>