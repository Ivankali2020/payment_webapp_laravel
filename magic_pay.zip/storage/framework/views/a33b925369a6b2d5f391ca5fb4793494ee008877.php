<?php $__env->startSection('title'); ?> Edit Admin  <?php $__env->stopSection(); ?>
<?php $__env->startSection('admin_index_active','mm-active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-users icon-gradient bg-mean-fruit">
                    </i>
                </div>
                <div> Edit Admin User </div>
            </div>

        </div>
    </div>

    <div class="row">
        <div class="col-7 m-auto">
            <div class="card card-body mt-3" >
                <?php if(session('status')): ?>
                    <?php echo e(session('status')); ?>

                <?php endif; ?>
                <form action="<?php echo e(url('admin/adminUser/'.$user->id)); ?>" method="post" id="update">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label for="">Name</label>
                        <input type="text"  class="form-control " name="name" value="<?php echo e($user->name); ?>" >

                    </div>

                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="text" class="form-control " name="email"  value="<?php echo e($user->email); ?>" >

                    </div>

                    <div class="form-group">
                        <label for="">Password</label>
                        <input type="password"  class="form-control " name="password"  placeholder="**** Should Change ******">

                    </div>

                    <div class="form-group">
                        <label for="">Phone</label>
                        <input type="number"  class="form-control  " name="phone"  value="<?php echo e($user->phone); ?>">

                    </div>

                    <div class="form-group text-right">
                        <button type="button" id="backBtn" class="btn btn-outline-secondary">Cancel</button>
                        <button type="submit" class="btn btn-info">Edit Admin</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\AdminUpdateRequest', '#update');; ?>

    <script>



        $(document).ready(function() {

        } );
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivan/Desktop/web/laravel7/MagicPayNew/resources/views/Backend/adminCRUD/edit.blade.php ENDPATH**/ ?>