<?php $__env->startSection('title','Wallet'); ?>
<?php $__env->startSection('style'); ?>
    <style>
    .wallet{
        cursor:pointer;
    }
    .wallet span{
        transition: .3s all ease ;
    }
    .wallet span:hover{
        color: skyblue;
    }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="card card-body wallet">

        <div class="d-flex justify-content-between flex-column  font-weight-bold  ">
            <div class="mb-3 wow fadeInDown ">
                <p  class="mb-2 text-uppercase text-muted ">Name</p>
                <span class="text-capitalize d-flex ">
                    <i class='pe-7s-angle-right align-self-center'></i>
                    <span><?php echo e($user->name); ?></span>
                </span>
            </div>
            <div class="mb-3 wow fadeInLeft">
                <p class="mb-2 text-uppercase text-muted ">Account Number</p>
                <span class="text-capitalize d-flex ">
                    <i class='pe-7s-angle-right align-self-center'></i>
                    <span class=""><?php echo e($user->getWallet ? $user->getWallet->acc_number: '-'); ?></span>

                </span>
            </div>
            <div class="mb-3 wow fadeInUp ">
                <p class="mb-2 text-uppercase text-muted ">Amount</p>
                <span class="text-capitalize d-flex ">
                    <i class='pe-7s-angle-right align-self-center'></i>

                    <span class="text-uppercase "> <?php echo e($user->getWallet ? number_format($user->getWallet->amount,2) : '-'); ?> mmk</span>
                </span>
            </div>

        </div>


    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        function askConfirm(){
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, LogOut!',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#click').click();

                }
            })
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivan/Desktop/web/laravel7/MagicPayNew/resources/views/Frontend/wallet.blade.php ENDPATH**/ ?>