<?php $__env->startSection('title','Transition'); ?>
<?php $__env->startSection('style'); ?>
    <style>

        .transfer img{
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: 1px solid deepskyblue;
            padding: 8px;
        }
        table td:first-child{
            animation: fadeInLeft calc(0.8s * 5) ;
        }
        table td:last-child{
            animation: fadeInRight calc(0.8s * 3) ;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="card-body card mt-2 ">

        <div class="mt-3 transfer text-center wow fadeIn   " data-wow-delay=".5s" data-wow-duration="2s">
            <img src="https://image.flaticon.com/icons/png/128/1055/1055183.png" alt="">
           <?php if($transition->type == 1): ?>
                <h6 class="mt-2 font-weight-bold "> Recived Money </h6>
            <?php else: ?>
                <h6 class="mt-2 font-weight-bold "> Transfer Money </h6>
            <?php endif; ?>
        </div>

        <div class="px-0 py-0 px-xl-5 mx-xl-5 ">
            <table class="table  px-lg-4 table-borderless   mt-3  ">
                <tbody>
                <?php if($transition->type == 1): ?>
                    <tr>
                        <td>From</td>
                        <td class="text-right "><?php echo e($transition->fromOtherUser->name); ?></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td class="text-right "><?php echo e($transition->fromOtherUser->phone); ?></td>
                    </tr>
                    <tr>
                        <td>Amount</td>
                        <td class="text-right ">+<?php echo e(number_format($transition->amount,2)); ?>Ks</td>
                    </tr>

                <?php elseif($transition->type == 2): ?>
                    <tr>
                        <td>To</td>
                        <td class="text-right "><?php echo e($transition->fromOtherUser->name); ?></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td class="text-right "><?php echo e($transition->fromOtherUser->phone); ?></td>
                    </tr>
                    <tr>
                        <td>Amount</td>
                        <td class="text-right "> -<?php echo e(number_format($transition->amount,2)); ?>Ks</td>
                    </tr>

                <?php endif; ?>

                <tr>
                    <td>Account Number</td>
                    <td class="text-right "> <?php echo e($transition->owner->getWallet->acc_number); ?> </td>
                </tr>
                <tr>
                    <td>Ref_id</td>
                    <td class="text-right "><?php echo e($transition->ref_id); ?></td>
                </tr>
                <tr class="text-wrap ">
                    <td>Description</td>
                    <td class="text-right "><?php echo e($transition->description? $transition->description : '-'); ?></td>
                </tr>

                </tbody>
            </table>
        </div>





    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('Frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivan/Desktop/web/laravel7/MagicPayNew/resources/views/Frontend/transitionDetail.blade.php ENDPATH**/ ?>