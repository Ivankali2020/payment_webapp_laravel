<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row align-items-center justify-content-center  min-vh-100  ">
        <div class="col-12 col-md-6 col-xl-5  mt-5">
            <div class="card border-0 shadow ">
                <div class="card-body  ">
                    <h4 class="text-uppercase text-center" >LogIn </h4>
                    <p class="text-center text-muted">Fill the form to login</p>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>








                        <div>
                            <label for="">Phone</label>
                            <input type="text" class="form-control mt-2" value="<?php echo e(old('phone')); ?>" name='phone'>
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span >
                            <strong class="text-danger "><?php echo e($message); ?></strong>
                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <div class="form-group mb-3 position-relative">
                        <label for="">Password</label>
                        <input type="password" class="form-control mt-2" name='password'  value="<?php echo e(old('password')); ?>" id="password">
                        <i class="fa fa-eye position-absolute mt-1  top-50 " style="right: 10px; cursor: pointer;" id="eye"></i>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span >
                            <strong class="text-danger phone"><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3 d-flex align-items-center justify-content-between">
                        <button class="btn btn-dark ">Login Now</button>
                        <a href="<?php echo e(route('register')); ?>" class="text-decoration-none">Not register yet?</a>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.app_plain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivan/Desktop/web/laravel7/MagicPayNew/resources/views/auth/login.blade.php ENDPATH**/ ?>