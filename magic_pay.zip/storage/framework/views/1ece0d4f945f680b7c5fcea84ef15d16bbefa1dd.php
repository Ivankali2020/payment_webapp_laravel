<?php if(session('toast')): ?>
    <script>

        let info = <?php echo json_encode(session('toast'), 15, 512) ?>;
        console.log(info);
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 5000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })

        Toast.fire({
            icon: info.icon,
            title: info.title
        })
    </script>

<?php endif; ?>
<?php /**PATH /home/ivan/Desktop/web/laravel7/MagicPayNew/resources/views/components/alert.blade.php ENDPATH**/ ?>