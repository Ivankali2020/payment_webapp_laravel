<?php $__env->startSection('title','Register'); ?>
<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row align-items-center justify-content-center min-vh-100">
        <div class="col-12 col-md-7">
            <div class="card border-0 shadow ">
                <div class="card-body">
                    <form action="<?php echo e(route('register')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <h4 class="text-uppercase text-center" >Sign Up</h4>
                        <p class="text-muted text-center" > Fill out the form to register </p>


                        <div class="form-group mb-3">
                            <label for="">Name</label>
                            <input type="text" value="<?php echo e(old('name')); ?>" class="form-control mt-2 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='name'>
                        </div>

                        <div class="form-group mb-3">
                            <label for="">Email</label>
                            <input type="email" value="<?php echo e(old('email')); ?>" class="form-control mt-2  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='email'>
                        </div>

                        <div class="form-group mb-3">
                            <label for="phone">Phone</label>
                            <input type="number" value="<?php echo e(old('phone')); ?>" class="form-control mt-2 <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name='phone'>
                        </div>

                        <div class="form-group mb-3 position-relative">
                            <label for="">Password</label>
                            <input type="password" class="form-control mt-2" name='password' id="password">
                            <i class="fa fa-eye position-absolute mt-1  top-50 " style="right: 10px; cursor: pointer;" id="eye"></i>
                        </div>

                        <div class="form-group mb-3 position-relative">
                            <label for="password_confirmation">Comfirm Password</label>
                            <input type="password" class="form-control mt-2" name='password_confirmation' id="password_confirmation">
                            <i class="fa fa-eye position-absolute mt-1  top-50 " style="right: 10px; cursor: pointer;" id="eye2"></i>
                        </div>

                        <div class="form-group mb-3 d-flex align-items-center justify-content-between">
                            <button class="btn btn-dark w-75">Sing Up</button>
                            <a href="<?php echo e(route('login')); ?>" class="text-decoration-none">Login Now?</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.app_plain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivan/Desktop/web/laravel7/MagicPayNew/resources/views/auth/register.blade.php ENDPATH**/ ?>