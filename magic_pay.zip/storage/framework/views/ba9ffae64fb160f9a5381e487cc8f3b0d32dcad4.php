<?php $__env->startSection('title',' Detail'); ?>
<?php $__env->startSection('style'); ?>
    <style>

        .transfer img{
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: 1px solid deepskyblue;
            padding: 8px;
        }
        table td:first-child{
            animation: fadeInLeft calc(0.8s * 5) ;
        }
        table td:last-child{
            animation: fadeInRight calc(0.8s * 3) ;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="card-body card mt-2  ">

       <div class="text-right wow fadeInRight ">
           <p class="mb-1 " >Notification</p>
           <samll class="text-muted mb-3  "><?php echo e($notification->created_at->format('d/m/Y H:i:s a')); ?></samll>
       </div>

        <div class=" font-weight-bolder text-center mt-4 wow fadeInDown">
            <p class="mb-1 ">Title </p>
            <p class="text-center"> <?php echo e($notification->data['title']); ?> </p>
        </div>
        <div class=" font-weight-bolder text-center mt-4  wow fadeInLeft">
            <p class="mb-1 ">Message</p>
            <p class=""> <?php echo e($notification->data['message']); ?> </p>
        </div>

        <div class="d-flex justify-content-between cborder wow  fadeInUp ">
            <p class="mb-1 text-muted ">Adidas</p>
            <a href=" <?php echo e($notification->data['web_link']); ?>" class="text-dark text-decoration-none ">Go Home</a>
        </div>


    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('Frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivan/Desktop/web/laravel7/MagicPayNew/resources/views/Frontend/notifications/detail.blade.php ENDPATH**/ ?>